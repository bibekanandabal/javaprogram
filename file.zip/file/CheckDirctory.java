package com.test.file;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CheckDirctory {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		//String directoryPath = "E:\\personal\\workspace\\JavaWork\\src\\com\\test\\file\\source";
		String directoryPath = "E:\\ITR Form";
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		
		Date dateStart = dateFormat.parse("01/11/2016");
		long startTs = dateStart.getTime();
		
		Date dateEnd = dateFormat.parse("17/11/2016");
		long endTs = dateEnd.getTime();
		
		CheckDirectoryUtility.checkAllFolderAndSubFolder(directoryPath, startTs, endTs);
		
		
	}
}
