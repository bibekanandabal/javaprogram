package com.test.file;

import java.io.File;
import java.util.Date;

public class CheckDirectoryUtility {
	
	public static void checkAllFolderAndSubFolder(String directoryPath, long startTs, long endTs){
		File directory = new File(directoryPath);
				
		File[] fileList = directory.listFiles();
		
		for (File file : fileList){
			
			if(file.isFile()){				
				Date lastModifiedDate  = new Date(file.lastModified());	
				Date startTimeStamp = new Date(startTs);
				Date endTimeStamp = new Date(endTs);				
				
				if (startTimeStamp.compareTo(lastModifiedDate) < 0 && endTimeStamp.compareTo(lastModifiedDate) > 0){
					System.out.println("List of File Available in Particular Time Stamp in the Directory " + file.getAbsolutePath() + " With Name " + file.getName());						
				}
				
			}else if (file.isDirectory()){
				checkAllFolderAndSubFolder(file.getAbsolutePath(), startTs, endTs);
			}
		}
	}
}
