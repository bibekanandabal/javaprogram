package com.test.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

public class FileCopyUtility {
	
	//Using the IO Strams
	public static void copyFileToDest(File source, File dest) throws Exception{
		InputStream is = null;
	    OutputStream os = null;
	    try {
	        is = new FileInputStream(source);
	        os = new FileOutputStream(dest);
	        byte[] buffer = new byte[1024];
	        int length;
	        while ((length = is.read(buffer)) > 0) {
	            os.write(buffer, 0, length);
	        }
	    } finally {
	        is.close();
	        os.close();
	    }
	}
	
	//Using Java 7 Streams
	public static void copyFileToDestination(File sourceFile, File destinationFile) throws Exception{
		
		Path source = sourceFile.toPath();
		Path destination = destinationFile.toPath();
		
		Files.copy(source, destination);
		
		
		
	}

}
