package com.test.file;

import java.io.File;

public class FileCopyUtilityTest {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		File source = new File("E:\\personal\\workspace\\JavaWork\\src\\com\\test\\file\\source\\FileToCopy.txt");
        File dest = new File("E:\\personal\\workspace\\JavaWork\\src\\com\\test\\file\\destination\\FileToCopy.txt");
        
        FileCopyUtility.copyFileToDest(source, dest);
        
        File sourceJ = new File("E:\\personal\\workspace\\JavaWork\\src\\com\\test\\file\\source\\FileToCopyJ7.txt");
        File destJ = new File("E:\\personal\\workspace\\JavaWork\\src\\com\\test\\file\\destination\\FileToCopyJ7.txt");
        
        FileCopyUtility.copyFileToDestination(sourceJ, destJ);

	}

}
