package com.test.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Paths;


public class ReadFileContent {
	
	
	/*
	 * Read the Content of a File By using the FileReader and BufferedREader
	 * Pre Java 1.7 concept
	 */
	public void readFile(File fileName) throws Exception{
		
		System.out.println(fileName);
		
		BufferedReader buf = null;
		
		try{			
			buf = new BufferedReader(new FileReader(fileName));
			
			String line;
			
			while ((line = buf.readLine()) != null){
				System.out.println(line);
			}
			
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			try {
                if (buf != null) {
                	buf.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
		}
		
	}
	
	/*
	 * Read the Content of a File By using NIO features
	 * Post Java 1.7 concept
	 */
	public void readFileContent(String fileName) throws Exception{
		String contents = new String(Files.readAllBytes(Paths.get(fileName)));	
		System.out.println(contents);		
	}

}
