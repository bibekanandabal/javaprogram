package com.test.file;

import java.io.File;

public class ReadFileContentTest {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		File f = new File("E:\\personal\\workspace\\JavaWork\\src\\com\\test\\file\\test");
		String filePath = "E:\\personal\\workspace\\JavaWork\\src\\com\\test\\file\\test";
		
		ReadFileContent fileRead = new ReadFileContent();
		fileRead.readFile(f);
		
		fileRead.readFileContent(filePath);

	}

}
